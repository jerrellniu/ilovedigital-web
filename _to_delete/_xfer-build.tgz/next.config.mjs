import { readFileSync, existsSync } from 'node:fs';

// 301 redirect map (old Squarespace URLs -> new), built from the live Squarespace
// sitemap at cutover. See the Content & Structure Audit URL table in Notion.
const raw = JSON.parse(
  readFileSync(new URL('./redirects.json', import.meta.url), 'utf-8')
);

// A 301 that lands on a page we have not written yet is worse than no redirect at
// all: the old URL's ranking is passed straight into a 404. Detail-page targets are
// resolved against the MDX on disk, and anything missing falls back to its hub until
// the article or case study exists. Nothing to remember at launch — write the file
// and the redirect starts pointing at it on the next build.
const hasDetailPage = (destination) => {
  const match = destination.match(/^\/(work|insights)\/(.+)$/);
  if (!match) return true;
  const [, section, slug] = match;
  return existsSync(new URL(`./content/${section}/${slug}.mdx`, import.meta.url));
};

const downgraded = [];
const redirects = raw.map((redirect) => {
  if (hasDetailPage(redirect.destination)) return redirect;
  const hub = `/${redirect.destination.split('/')[1]}`;
  downgraded.push(`${redirect.source} -> ${redirect.destination} (falling back to ${hub})`);
  return { ...redirect, destination: hub };
});

if (downgraded.length > 0) {
  console.warn(
    `\n[redirects] ${downgraded.length} redirect(s) point at a page that does not exist yet:\n` +
      downgraded.map((line) => `  ${line}`).join('\n') +
      '\n'
  );
}

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  async redirects() {
    return redirects;
  },
};

export default nextConfig;
