# Site images — conventions

Every image the site serves lives here, under `public/images/`, and is committed to the
repo. Next.js serves these off Vercel's CDN and optimises them at request time via
`next/image` (resize, WebP/AVIF, lazy-load). You supply one good-quality source file per
slot; the framework handles the rest.

Full-resolution originals (shoots, exports, source files) are archived in Google Drive —
**not** committed here. Only the web-ready file for each slot goes in the repo.

## Folders

| Folder                 | What goes here                                              |
| ---------------------- | ---------------------------------------------------------- |
| `public/images/work/`     | Case-study card thumbnails (one per case study)         |
| `public/images/insights/` | Blog-post card thumbnails (one per post)                |
| `public/images/founder/`  | Jerrell portrait + candid photos                        |

## Naming

Name each file after the slug or slot it fills, lower-case with hyphens:

- Case study: `public/images/work/<work-slug>.jpg` — e.g. `the-boxing-shop.jpg`
  (slugs come from `content/work/index.json` → the last segment of `href`).
- Blog post: `public/images/insights/<post-slug>.jpg` — e.g. `complete-seo-checklist-2026.jpg`
  (slugs come from `content/insights/index.json` → `slug`).
- Founder: `public/images/founder/jerrell-portrait.jpg` and `jerrell-candid.jpg`.

## Specs

| Slot                    | Ratio | Export size (px) | Format |
| ----------------------- | ----- | ---------------- | ------ |
| Case-study card         | 16:10 | 1200 × 750       | JPG    |
| Blog-post card          | 16:10 | 1200 × 750       | JPG    |
| Founder portrait (About hero, Home founder block) | 4:5 | 1000 × 1250 | JPG |
| Founder candid (About "Off the clock") | 4:3 | 1200 × 900 | JPG |
| Logo                    | vector | —               | SVG (`public/logo.svg`) |

Export JPG at ~80% quality. Keep each file under ~400 KB before commit; `next/image`
compresses further on the fly. Use PNG only where transparency is required.

## How to switch a slot on

Each image slot is optional in the content files and falls back to a brand gradient when
empty, so the site never shows a broken image. To turn a real image on, drop the file in
the right folder and add its path to the matching content record.

**Case study** — in `content/work/index.json` (and, for the four Home cards,
`content/pages/home.json` → `featuredWork.cards`), add an `image` key:

```json
{
  "client": "The Boxing Shop",
  "tag": "Web",
  "headline": "Shopify Dawn rebuild for a Gold Coast combat sports retailer.",
  "outcome": "Modern ecommerce, mobile-perfect, built to convert.",
  "href": "/work/the-boxing-shop",
  "image": "/images/work/the-boxing-shop.jpg"
}
```

**Blog post** — in `content/insights/index.json`, add an `image` key to the post record.

**Founder** — in `content/pages/about.json` set `hero.image` and `outsideWork.image`; in
`content/pages/home.json` set `founder.image`. Example:

```json
"hero": { "eyebrow": "About", "heading": "Hi, I'm Jerrell.", "sub": "…", "image": "/images/founder/jerrell-portrait.jpg" }
```

Paths are site-absolute (they start with `/images/...`, not `public/`).
