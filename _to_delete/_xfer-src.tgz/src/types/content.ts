// Typed shapes for the JSON content files. Every page's copy is validated against
// one of these shapes so the build fails loudly if a content file drifts.

export interface CtaLink {
  label: string;
  href: string;
}

export interface Faq {
  question: string;
  answer: string;
}

/**
 * A Google Calendar appointment schedule. `href` is the public booking page,
 * `embedUrl` is the same URL with `?gv=true` so it renders inside an iframe.
 * Both are stored rather than derived, so a schedule that needs a different
 * query string later does not require a code change.
 */
export interface BookingSchedule {
  label: string;
  href: string;
  embedUrl: string;
}

export interface SiteContent {
  name: string;
  tagline: string;
  phone: string;
  abn: string;
  email: string;
  location: string;
  booking: CtaLink;
  schedules: {
    discovery15: BookingSchedule;
    meeting30: BookingSchedule;
  };
  socials: { label: string; href: string }[];
  nav: CtaLink[];
  services: CtaLink[];
  footer: {
    usefulLinks: CtaLink[];
    resources: CtaLink[];
    resourcesNote?: string;
  };
  legal: CtaLink[];
  cookieNotice: string;
}

export interface HeroBlock {
  eyebrow?: string;
  heading: string;
  sub: string;
  image?: string;
  imageAlt?: string;
  primaryCta?: CtaLink;
  secondaryCta?: CtaLink;
}

export interface Stat {
  value: string;
  label: string;
}

export interface Pillar {
  key: 'websites' | 'search' | 'social' | 'ai';
  name: string;
  heading: string;
  oneLiner: string;
  bullets: string[];
  href: string;
}

export interface CaseStudyCardData {
  client: string;
  tag: string;
  headline: string;
  /** Supporting line under the headline. Omitted when the headline says it all. */
  outcome?: string;
  /**
   * Always set in the content files. Cleared at load time by the loaders in
   * `src/lib/content.ts` when the linked case study isn't published, so the card
   * renders unlinked instead of pointing at a 404.
   */
  href?: string;
  /** 16:10 thumbnail under public/. Falls back to the gradient placeholder when absent. */
  image?: string;
  /**
   * Alt text for `image`. Defaults to "<client> website" — set this whenever the
   * thumbnail is not a website screenshot (a social feed, brand collateral, print).
   */
  imageAlt?: string;
  /** Build platform (Shopify, WordPress, NextJS, Wix, Squarespace). Pill is omitted when absent. */
  platform?: string;
}

export interface Testimonial {
  quote: string;
  author: string;
}

export interface ProcessStep {
  title: string;
  body: string;
}

export interface HomeContent {
  meta: { title: string; description: string };
  hero: HeroBlock;
  stats: Stat[];
  pillarsIntro: { eyebrow: string; heading: string; sub: string };
  pillars: Pillar[];
  featuredWork: { eyebrow: string; heading: string; sub: string; cards: CaseStudyCardData[]; footerCta: CtaLink };
  testimonials: { heading: string; sub: string; items: Testimonial[] };
  founder: {
    eyebrow: string;
    heading: string;
    image?: string;
    imageAlt?: string;
    paragraphs: string[];
    cta: CtaLink;
  };
  process: { eyebrow: string; heading: string; sub: string; steps: ProcessStep[]; cta: CtaLink };
  audit: { heading: string; sub: string; button: string; belowLink: CtaLink };
  faq: { heading: string; items: Faq[] };
  finalCta: { heading: string; sub: string; button: CtaLink };
}

export interface ServicePageContent {
  meta: { title: string; description: string };
  hero: HeroBlock;
  included: { heading: string; items: string[] };
  platforms?: { label: string; items: string[] };
  note?: string;
  howItWorks?: string;
  relatedWork?: CaseStudyCardData | null;
  relatedWorkNote?: string;
  faq: Faq[];
  ctaBand: { heading: string; button: CtaLink };
}
